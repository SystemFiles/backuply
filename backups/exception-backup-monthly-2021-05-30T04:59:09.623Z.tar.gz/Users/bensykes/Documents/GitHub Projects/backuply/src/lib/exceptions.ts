export class PathNotExistsException extends Error {
	// TODO
}
